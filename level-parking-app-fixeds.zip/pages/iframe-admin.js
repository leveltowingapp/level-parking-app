export default function DashboardView() {
  return (
    <div>
      <h1>Iframe View of Admin Dashboard</h1>
      <iframe
        src="/admin"
        width="100%"
        height="600px"
        style={{ border: "1px solid #ccc", borderRadius: "8px" }}
      ></iframe>
    </div>
  );
}
