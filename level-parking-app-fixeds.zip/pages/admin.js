export default function Admin() {
  return (
    <div>
      <h1>Admin Dashboard</h1>
      <p>Manage Tenants, Lots, and Violations</p>
    </div>
  );
}
