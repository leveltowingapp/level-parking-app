
export default function Home() {
  return (
    <div>
      <h1>Welcome to Level Parking</h1>
      <p>This is the live demo homepage.</p>
    </div>
  );
}
